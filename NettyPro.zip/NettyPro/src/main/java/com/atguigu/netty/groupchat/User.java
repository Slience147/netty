package com.atguigu.netty.groupchat;

public class User {
    private int id;
    private String pwd;
}
